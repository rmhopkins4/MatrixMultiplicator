import matrixMultiplicator.Matrix;

public class Driver {
	
	public static void main(String[] args) {
		
		int[][] arrA = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
		Matrix A = new Matrix(arrA);
		Matrix B = new Matrix(A);
		
		System.out.println(A == B);
		
	}
}
