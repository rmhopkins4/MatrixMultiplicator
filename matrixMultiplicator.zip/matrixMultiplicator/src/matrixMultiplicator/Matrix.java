package matrixMultiplicator;

public class Matrix {
	private int[][] matrix;
	
	public Matrix(int[][] matrix) {
		int rowLength = matrix[0].length;
		for(int[] row : matrix) {
			if(row.length != rowLength) {
				throw new IllegalArgumentException("Ragged array");
			}
		}
		
		int[][] matrixCopy = new int[matrix.length][matrix[0].length];
		for(int i = 0; i < matrix.length; ++i) {
			for(int j = 0; j < matrix[0].length; ++j) {
				matrixCopy[i][j] = matrix[i][j];
			}
		}
		this.matrix = matrixCopy;
	}
	
	public Matrix(Matrix other) {
		matrix = new int[other.getNumRows()][other.getNumCols()];
		for(int i = 0; i < matrix.length; ++i) {
			for(int j = 0; j < matrix[0].length; ++j) {
				matrix[i][j] = other.matrix[i][j];
			}
		}
	}
	
	public int getNumRows() {
		return matrix[0].length;
	}
	
	public int getNumCols() {
		return matrix.length;
	}
	
	public int[] getRow(int row) {
		int[] rowTemp = new int[matrix[row].length];
		for(int i = 0; i < matrix[row].length; ++i) {
			rowTemp[i] = matrix[row][i];
		}
		
		return rowTemp;
	}
	
	public int[] getCol(int col) {
		int[] colTemp = new int[matrix.length];
		for(int i = 0; i < matrix.length; ++i) {
			colTemp[i] = matrix[i][col];
		}
		
		return colTemp;
	}
	
	private static int dotProduct(int[] colVector, int[] rowVector) {
		if(colVector.length != rowVector.length) {
			throw new IllegalArgumentException();
		}
		int product = 0;
		for(int i = 0; i < colVector.length; ++i) {
			product += colVector[i] * rowVector[i];
		}
		return product;
	}
	
	public Matrix multiplyMatrix(Matrix B) {
		if(this.getNumRows() != B.getNumCols()) {
			throw new IllegalArgumentException
			("Dimensions do not work for multiplication");
		}
		
		int[][] resultMatrix = new int[this.getNumCols()][B.getNumRows()];
		
		for(int i = 0; i < resultMatrix.length; ++i) {
			for(int j = 0; j < resultMatrix[0].length; ++j) {
				resultMatrix[i][j] = Matrix.dotProduct(this.getRow(i), B.getCol(j));
			}
		}
		
		return new Matrix(resultMatrix);
	}
	
	public int findDeterminant() {
		return findDeterminantHelper(this);
	}
	
	private int findDeterminantHelper(Matrix square) {
		if(square.getNumCols() != square.getNumRows()) {
			throw new IllegalArgumentException("Not a square matrix!");
		}
		
		if(square.getNumCols() == 1) {
			return square.matrix[0][0];
		}
		
		if(square.getNumCols() == 2) { //if 2 x 2
			
			return (square.matrix[0][0] * square.matrix[1][1]) - 
					(square.matrix[1][0] * square.matrix[0][1]);
		}
		
		int determinant = 0;
		for(int i = 0; i < square.getNumCols(); i++) {
			
			determinant += ((square.matrix[0][i] * (int) Math.pow(-1, i)) * 
					(findDeterminantHelper(getRemainingMatrix(i, this))));
		}
		return determinant;
	}
	
	private static Matrix getRemainingMatrix(int index, Matrix original) {
		int[][] remainingMatrix = new int[original.getNumCols() - 1][original.getNumCols() - 1];
		
		for(int i = 1; i < original.matrix.length; ++i) {
			int offset = 0;
			for(int j = 0; j < original.matrix.length - 1; ++j) {
				if(j == index) {
					offset = 1;
				}
				remainingMatrix[i - 1][j] = original.matrix[i][j + offset];
			}
		}
		return new Matrix(remainingMatrix);
	}
	
	public String toString() {
		String output = "{";
		for(int i = 0; i < matrix.length; ++i) {
			output += "{";
			for(int j = 0; j < matrix[0].length; ++j) {
				output += " " + matrix[i][j] + ", ";
			}
			output += "}";
		}
		return output += "}";
	}
	
	public boolean equals(Object other) {
		if(!(other instanceof Matrix)) {
			return false;
		}
		Matrix o = (Matrix)other;
		if(o.getNumCols() != this.getNumCols() || 
				o.getNumRows() != this.getNumRows()) {
			return false;
		}
		boolean isSame = true;
		for(int i = 0; i < this.matrix.length; ++i) {
			for(int j = 0; j < this.matrix[0].length; ++j) {
				if(o.matrix[i][j] != this.matrix[i][j]) {
					isSame = false;
				}
			}
		}
		return isSame;
	}
}
